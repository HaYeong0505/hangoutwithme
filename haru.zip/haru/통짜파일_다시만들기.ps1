﻿# 2_분리파일 폴더의 HTML/CSS/JS/로고를 하나로 합쳐 1_통짜파일\hangout-with-me.html 을 다시 만들어요.
# 분리파일을 고친 뒤 이 파일을 실행하면 돼요:  powershell -ExecutionPolicy Bypass -File .\통짜파일_다시만들기.ps1
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $root "2_분리파일"
$outDir = Join-Path $root "1_통짜파일"
New-Item -ItemType Directory -Force $outDir | Out-Null
$enc = New-Object System.Text.UTF8Encoding($false)
$html = [IO.File]::ReadAllText("$src\index.html", $enc)
$css = [IO.File]::ReadAllText("$src\css\style.css", $enc)
$logo = "data:image/png;base64," + [Convert]::ToBase64String([IO.File]::ReadAllBytes("$src\logo.png"))
$html = $html.Replace('<link rel="stylesheet" href="css/style.css">', "<style>`n$css`n</style>")
$html = $html.Replace('src="./logo.png"', "src=""$logo""")
foreach ($m in [regex]::Matches($html, '<script src="js/([\w-]+)\.js"></script>')) {
  $n = $m.Groups[1].Value
  $js = [IO.File]::ReadAllText("$src\js\$n.js", $enc)
  $html = $html.Replace($m.Value, "<script>/* ===== js/$n.js ===== */`n$js`n</script>")
}
[IO.File]::WriteAllText("$outDir\hangout-with-me.html", $html, $enc)
Write-Host "완료: $outDir\hangout-with-me.html"
