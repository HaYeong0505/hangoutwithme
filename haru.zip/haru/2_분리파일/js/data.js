// 예시 데이터와 화면 상태(S): 공모전(C), 팀 모집글(TM), 내 지원·후기·완료 프로젝트, 팀채팅 방(room)

const LV={1:"초보",2:"중급",3:"고급"},T=new Date(2026,10,19),MYT=2,GR=["#3a6df0,#7b3ff0","#f0623a,#f0a13a","#10a58a,#2b6de0","#d6264a,#7b2ff0"];
const C=[
{id:1,t:"MTN 중소기업 광고 공모전",h:"MTN",p:"2026-11-03",d:"2026-12-04",info:"중소기업 제품·서비스를 알리는 광고 아이디어와 15초 영상 시안을 공모합니다.",who:"대학생·대학원생 (팀 최대 4명)",prize:"대상 300만원 · 최우수상 150만원 · 우수상 50만원",sub:"광고 기획서(PDF 10장 이내) + 15초 영상 시안",url:"https://example.com/mtn",roles:["기획","카피","디자인","영상"]},
{id:2,t:"서울 영상 공모전 밤로그",h:"서울시",p:"2026-10-27",d:"2026-11-27",info:"서울의 밤 풍경을 담은 1분 이내 숏폼 영상을 모집합니다.",who:"서울 소재 대학 재학생·휴학생 누구나",prize:"대상 200만원 · 입선 10팀 각 20만원",sub:"세로형 숏폼 영상(1분 이내, mp4)",url:"https://example.com/nightlog",roles:["기획","영상"]},
{id:3,t:"AI 융합교육 플랫폼 챌린지",h:"교육부",p:"2026-11-10",d:"2026-12-18",info:"교육용 AI 서비스를 직접 구현해 발표하는 개발 공모전입니다.",who:"전국 대학생 (2~5인 팀)",prize:"장관상 500만원 · 우수상 200만원 · 장려상 100만원",sub:"동작하는 서비스 데모 + 발표 자료 + GitHub 저장소",url:"https://example.com/ai-edu",roles:["기획","프론트","백엔드"]},
{id:4,t:"연구재단 50주년 엠블럼 디자인",h:"한국연구재단",p:"2026-11-01",d:"2026-12-02",info:"재단 50주년을 기념하는 엠블럼 디자인을 공모합니다.",who:"제한 없음 (개인·팀 모두 가능)",prize:"최우수 1점 300만원 · 우수 2점 각 100만원",sub:"엠블럼 원본(AI) + 설명서(A4 1장)",url:"https://example.com/emblem",roles:["디자인"]}];
// desc = 팀 설명 (게시판 상세에 보여요)
const TM=[
{id:1,cid:1,name:"광고쟁이들",lv:2,cond:"주 1회 온라인 회의, 11월 안에 시안 완성",desc:"광고 동아리 출신 기획자와 영상 담당이 모였어요. 아이디어 회의는 자유롭게, 마감은 확실하게 지키는 팀이에요. 카피와 디자인을 맡아 줄 분을 찾고 있어요.",mem:["이도윤(기획)","박서준(영상)"],max:4,need:["카피","디자인"]},
{id:2,cid:2,name:"숏폼 메이커스",lv:1,cond:"초보 환영, 주말 촬영 가능한 분",desc:"영상 공모전이 처음인 사람들끼리 모여 하나씩 배우면서 만들어요. 촬영 장비는 팀에서 빌려 드려요.",mem:["김하늘(기획)","최유나(기획)","정민호(영상)"],max:4,need:["영상"]},
{id:3,cid:3,name:"AI 에듀팀",lv:3,cond:"Git 사용 가능, 주 2회 회의",desc:"초등학생용 AI 학습 도우미를 만들 계획이에요. 프론트는 React로 시작했고, API 서버를 함께 설계할 백엔드와 서비스 기획자를 찾아요.",mem:["한지우(프론트)"],max:4,need:["백엔드","기획"]},
{id:4,cid:4,name:"로고 연구소",lv:2,cond:"시안 3개 이상 제작 가능한 분",desc:"시각디자인과 3학년이 만든 팀이에요. 서로 시안을 피드백하면서 완성도를 높여 가요.",mem:["윤서아(디자인)"],max:3,need:["디자인"]},
{id:5,cid:2,name:"밤산책 필름",lv:1,cond:"촬영·편집 둘 다 처음이어도 괜찮아요",desc:"밤 산책을 좋아하는 사람들의 감성 숏폼 팀이에요. 한강·남산 야경을 찍을 예정이에요.",mem:["강민서(기획)"],max:3,need:["영상","기획"]}];
// bc·bq = 게시판 공모전 필터·검색어, cr·cs = 주요공모전 직군 필터·정렬, ctr = 공모전 상세의 팀 직군 필터, pre = 모집글 작성 시 미리 채울 공모전
const S={user:null,am:"in",f:0,bc:0,bq:"",cr:"전체",cs:"d",ctr:"전체",pre:"",tid:1,tt:"nt",lf:"전체",cm:{y:2026,m:10},mm:{y:2026,m:10},sel:"",rate:5,
apps:[{tid:1,role:"디자인",intro:"",st:"a"},{tid:3,role:"백엔드",intro:"Spring 프로젝트 경험이 있어요.",st:"c",res:"불"},{tid:4,role:"디자인",intro:"로고 작업물이 있어요.",st:"c",res:"합"}],
recv:[{tid:2,n:"정다은",role:"영상",intro:"브이로그 편집 경험이 있어요.",aff:"한국대학교 미디어커뮤니케이션학과 3학년",car:["유튜브 브이로그 채널 운영 (2년, 구독자 1.2만)","교내 홍보영상 촬영·편집 (2025)"],aw:["2025 대학생 숏폼 공모전 우수상"],pf:[{t:"브이로그 편집 모음",u:"https://example.com/vlog"},{t:"교내 홍보영상",u:"https://example.com/promo"}],rt:4.8},
{tid:2,n:"오세훈",role:"영상",intro:"처음이지만 열심히 할게요.",aff:"서울대학교 경영학과 1학년",car:[],aw:[],pf:[{t:"스마트폰으로 찍은 여행 영상",u:"https://example.com/trip"}],rt:0}],
prof:{aff:"",aw:["2025 교내 아이디어톤 장려상"],pf:[{t:"브랜드 리디자인",u:"https://example.com"}]},
rv:[{w:"박서준",s:5,t:"일정 관리가 꼼꼼해서 같이 하기 편했어요."},{w:"이도윤",s:4,t:"아이디어가 많고 피드백이 빨라요."}],
done:[{id:1,name:"브랜드 리디자인 크루",comp:"2026 대학생 브랜드 공모전",end:"2026-09-30",role:"디자인",res:"우수상",mem:[{n:"박서준",r:"영상"},{n:"이도윤",r:"기획"},{n:"최유나",r:"카피"}]},
{id:2,name:"아이디어톤 3조",comp:"2025 교내 아이디어톤",end:"2025-11-15",role:"기획",res:"장려상",mem:[{n:"한지우",r:"프론트"},{n:"정민호",r:"백엔드"}]}],
gv:[{p:1,n:"박서준",s:5,t:"촬영 일정 맞추느라 고생 많으셨어요. 결과물 최고였어요!"}]};
const SMP={img:(()=>{const c=document.createElement("canvas");c.width=640;c.height=400;const x=c.getContext("2d"),g=x.createLinearGradient(0,0,640,400);g.addColorStop(0,"#e71b1b");g.addColorStop(1,"#ff7a3a");x.fillStyle=g;x.fillRect(0,0,640,400);x.fillStyle="#fff";x.font="bold 40px sans-serif";x.textAlign="center";x.fillText("Reference 1",320,215);return c.toDataURL("image/png")})(),
pdf:(()=>{const st="BT /F1 24 Tf 60 100 Td (Sample reference PDF) Tj ET",ob=["<</Type/Catalog/Pages 2 0 R>>","<</Type/Pages/Kids[3 0 R]/Count 1>>","<</Type/Page/Parent 2 0 R/MediaBox[0 0 400 200]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>",`<</Length ${st.length}>>\nstream\n${st}\nendstream`,"<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>"];
let s="%PDF-1.4\n";const off=ob.map((o,i)=>{const p=s.length;s+=`${i+1} 0 obj\n${o}\nendobj\n`;return p});const x=s.length;
s+=`xref\n0 ${ob.length+1}\n0000000000 65535 f \n`+off.map(p=>String(p).padStart(10,"0")+" 00000 n \n").join("")+`trailer\n<</Size ${ob.length+1}/Root 1 0 R>>\nstartxref\n${x}\n%%EOF`;
return URL.createObjectURL(new Blob([s],{type:"application/pdf"}))})()};
const R={},room=t=>R[t]||(R[t]={nt:[{t:"첫 회의 안내",b:"이번 주 토요일 오후 2시에 온라인으로 모여요.",u:"",img:"",d:"11/17"}],
msgs:[{w:"이도윤",t:"안녕하세요! 이번 주 회의 시간 정해봐요.",h:"오후 2:10",ck:2,my:0},{w:"박서준",t:"토요일 오후 괜찮아요.",h:"오후 2:14",ck:1,my:0}],
lib:[{k:"링크",n:"공모전 요강 페이지",u:"https://example.com"},{k:"PDF",n:"참고자료.pdf",f:SMP.pdf},{k:"이미지",n:"레퍼런스1.png",f:SMP.img}],
vt:[{q:"회의 방식은?",o:[{x:"온라인",n:2},{x:"대면",n:1}],my:-1}],
ev:[{d:"2026-11-21",t:"1차 회의",todo:0,done:0},{d:"2026-11-25",t:"시안 초안 제출",todo:1,done:0}],av:{}});
const myApp=id=>S.apps.find(a=>a.tid===id);
