// 화면 그리기(render)와 이벤트 연결 — 가장 마지막에 불러와야 해요
// 주소 형식: #페이지 또는 #페이지/번호 (예: #post/3 = 3번 모집글 상세, #contest/2 = 2번 공모전 상세)

function render(){const [h,q]=(location.hash.slice(1)||"home").split("/"),on=h==="post"?"board":h;
$("#menu").innerHTML=[["board","게시판"],["contest","주요공모전"],["recruit","모집글"],["team","팀채팅"],["mypage","마이페이지"]].map(([k,n])=>`<a href="#${k}" class="${on===k?"on":""}">${n}</a>`).join("");
$("#auth").innerHTML=S.user?`<span>${E(S.user.name)}님</span><a href="#" data-a="logout">로그아웃</a><a href="#" data-a="quit">회원탈퇴</a>`:`<a href="#" data-a="login">로그인</a><a href="#" data-a="join">회원가입</a>`;
$("#app").innerHTML=({home:pHome,board:pBoard,post:pPost,contest:pContest,recruit:pRecruit,team:pTeam,mypage:pMy}[h]||pHome)(q);
const ms=$("#ms");if(ms)ms.scrollTop=ms.scrollHeight}
document.addEventListener("click",e=>{const b=e.target.closest("[data-a]");if(!b)return;if(b.tagName==="A")e.preventDefault();act(b.dataset.a,b)});
document.addEventListener("change",e=>{const id=e.target.id;if(id==="tsel"){S.tid=+e.target.value;render()}else if(id==="bsel"){S.bc=+e.target.value;render()}else if(id==="csort"){S.cs=e.target.value;render()}});
document.addEventListener("keydown",e=>{if(e.key!=="Enter")return;if(e.target.id==="ci")act("send",e.target);else if(e.target.id==="bq")act("bsearch",e.target)});
document.addEventListener("input",e=>{if(e.target.id==="ai")$("#aic").textContent=e.target.value.length});
addEventListener("hashchange",()=>{if(location.hash!=="#recruit"){S.edit=0;S.pre=""}S.ctr="전체";render();scrollTo(0,0)});
render();
