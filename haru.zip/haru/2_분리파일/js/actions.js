// 모달 창과 버튼 동작(act): 버튼의 data-a 값에 따라 처리

function openM(h,w){$("#bx").innerHTML=h;$("#bx").style.maxWidth=w||"";$("#md").classList.add("on")}const closeM=()=>$("#md").classList.remove("on");
function authM(){const up=S.am==="up";openM(`<div class="tabs" style="margin:0 0 8px"><button class="${up?"":"on"}" data-a="am" data-v="in">로그인</button><button class="${up?"on":""}" data-a="am" data-v="up">회원가입</button></div>${up?`<label for="ae">이메일</label><input id="ae" type="email"><label for="an">이름</label><input id="an">`:""}<label for="aid">ID</label><input id="aid"><label for="apw">비밀번호</label><input id="apw" type="password">
<div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">취소</button><button class="btn r" data-a="authOk">${up?"가입하기":"로그인"}</button></div>`)}
// [게시판 파트] 지원 모달: 희망 직무 + 자기소개서 (r = 상세 화면에서 누른 직무를 미리 선택)
function applyM(id,r){const t=TM.find(x=>x.id===id),c=C.find(x=>x.id===t.cid);openM(`<p class="m" style="margin:0">${E(c.t)}</p><h3 style="margin:0 0 2px">${E(t.name)} 지원하기</h3><p class="m" style="margin:0"><span class="lv l${t.lv}">${LV[t.lv]}</span> ${E(t.cond)}</p>
<label for="ar">희망 직무</label><select id="ar">${t.need.map(x=>`<option ${x===r?"selected":""}>${E(x)}</option>`).join("")}</select>
<label for="ai">자기소개서</label><textarea id="ai" rows="7" maxlength="500" placeholder="관련 경험, 맡고 싶은 역할, 참여 가능한 시간 등을 적어 주세요. (10자 이상)"></textarea><p class="m cnt"><span id="aic">0</span> / 500자</p>
<label style="display:flex;align-items:center;gap:6px;cursor:pointer;margin-top:4px"><input type="checkbox" id="apf" checked style="margin:0">내 프로필(소속 · 수상내역 · 포폴)도 함께 보내기</label>
<div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">취소</button><button class="btn r" data-a="applyOk" data-id="${id}">지원하기</button></div>`,"560px");$("#ai").focus()}

function act(a,b){const d=b.dataset,r=S.user?room(S.tid):null;
switch(a){
case"login":case"join":S.am=a==="join"?"up":"in";return authM();
case"am":S.am=d.v;return authM();
case"authOk":{const id=$("#aid").value.trim(),pw=$("#apw").value;if(!id||!pw)return toast("ID와 비밀번호를 입력해 주세요.");let nm="김하늘",em=id+"@example.com";
if(S.am==="up"){nm=$("#an").value.trim();em=$("#ae").value.trim();if(!nm||!em)return toast("이메일과 이름을 입력해 주세요.")}
S.user={name:nm,id,email:em};closeM();toast(S.am==="up"?"가입이 완료됐어요.":"로그인했어요.");break}
case"logout":S.user=null;location.hash="home";toast("로그아웃했어요.");break;
case"quit":return openM(`<h3 style="margin:0 0 6px">회원탈퇴</h3><p class="m">탈퇴하면 프로필과 지원 내역이 삭제돼요. (데모)</p><div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">취소</button><button class="btn r" data-a="quitOk">탈퇴하기</button></div>`);
case"quitOk":S.user=null;closeM();location.hash="home";toast("회원탈퇴가 완료됐어요.");break;
case"close":return closeM();
case"apply":if(!S.user){toast("로그인이 필요해요.");return authM()}return applyM(+d.id,d.r);
case"applyOk":{const intro=$("#ai").value.trim();if(intro.length<10)return toast("자기소개서를 10자 이상 작성해 주세요.");if(myApp(+d.id))return toast("이미 지원한 팀이에요.");
S.apps.push({tid:+d.id,role:$("#ar").value,intro,pf:$("#apf").checked?1:0,st:"w"});closeM();toast("지원했어요. 마이페이지에서 현황을 확인하세요.");break}
case"cancelApp":return openM(`<h3 style="margin:0 0 6px">지원 취소</h3><p class="m">"${E(TM.find(t=>t.id===+d.id).name)}" 팀 지원을 취소할까요? 작성한 자기소개서도 함께 지워져요.</p><div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">닫기</button><button class="btn r" data-a="cancelOk" data-id="${d.id}">지원 취소</button></div>`);
case"cancelOk":S.apps=S.apps.filter(a=>a.tid!==+d.id);closeM();toast("지원을 취소했어요.");break;
case"bsearch":S.bq=$("#bq").value.trim();break;
case"bclr":S.bq="";S.bc=0;break;
case"cr":S.cr=d.v;break;
case"ctr":S.ctr=d.v;break;
case"mkTeam":{const c=C.find(x=>x.id===+d.id);S.edit=0;S.pre=c.t;if(!S.user)toast("로그인 후 모집글을 작성할 수 있어요.");location.hash="recruit";return}
case"recruitOk":{const ct=$("#rcid").value.trim();if(!ct)return toast("대상 공모전을 입력해 주세요.");
let cc=C.find(c=>c.t===ct);if(!cc){cc={id:Math.max(0,...C.map(c=>c.id))+1,t:ct,h:"",d:"",info:"",roles:[],u:1};C.push(cc)}
const cid=cc.id,name=$("#rname").value.trim(),lv=+$("#rlv").value,max=Math.max(2,+$("#rmax").value||4),cond=$("#rcond").value.trim(),desc=$("#rdesc").value.trim(),need=$("#rneed").value.split(",").map(x=>x.trim()).filter(Boolean);
if(!name||!cond||!need.length)return toast("팀명, 모집 조건, 모집 직무를 모두 입력해 주세요.");
if(S.edit){const t=TM.find(x=>x.id===S.edit);Object.assign(t,{cid,name,lv,cond,desc,max:Math.max(max,t.mem.length),need});S.edit=0;S.pre="";toast("모집글을 수정했어요.");location.hash="post/"+t.id;return}
const id=Math.max(0,...TM.map(x=>x.id))+1;
TM.unshift({id,cid,name,lv,cond,desc,mem:[S.user.name+"(팀장)"],max,need,own:1});S.pre="";
toast("모집글이 등록됐어요.");location.hash="post/"+id;return}
case"edit":S.edit=+d.id;if(location.hash==="#recruit")break;location.hash="recruit";return;
case"del":{const t=TM.find(x=>x.id===+d.id);return openM(`<h3 style="margin:0 0 6px">모집글 삭제</h3><p class="m">"${E(t.name)}" 모집글을 삭제할까요? 삭제하면 되돌릴 수 없어요.</p><div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">취소</button><button class="btn r" data-a="delOk" data-id="${t.id}">삭제하기</button></div>`)}
case"delOk":{const i=TM.findIndex(x=>x.id===+d.id);if(i>=0)TM.splice(i,1);S.apps=S.apps.filter(a=>a.tid!==+d.id);closeM();toast("모집글을 삭제했어요.");if(location.hash.startsWith("#post/")){location.hash="board";return}break}
case"bf":S.f=+d.v;break;
case"tt":S.tt=d.v;break;case"lf":S.lf=d.v;break;
case"mv":{const o=location.hash==="#mypage"?S.mm:S.cm;o.m+=+d.v;if(o.m<0){o.m=11;o.y--}if(o.m>11){o.m=0;o.y++}break}
case"sel":S.sel=d.d;break;
case"ntAdd":{const t=$("#nti").value.trim();if(!t)return toast("공지 제목을 입력해 주세요.");const f=$("#nim").files[0];let fk="";if(f){fk=okImg(f)?"img":okPdf(f)?"pdf":/^video\/mp4$/.test(f.type)||/\.mp4$/i.test(f.name)?"mp4":"";if(!fk)return toast("공지 첨부는 pdf, jpg, png, mp4 파일만 올릴 수 있어요.")}
r.nt.unshift({t,b:$("#ntb").value.trim(),u:$("#ntu").value.trim(),f:f?URL.createObjectURL(f):"",fn:f?f.name:"",fk,d:"방금"});break}
case"send":{const v=$("#ci").value.trim();if(!v)return;r.msgs.push({w:S.user.name,t:v,h:new Date().toLocaleTimeString("ko-KR",{hour:"numeric",minute:"2-digit"}),ck:0,my:0,me:1});render();return $("#ci").focus()}
case"ck":{const m=r.msgs[+d.i];m.my=m.my?0:1;break}
case"pvn":{const x=r.nt[+d.i];return openM(`<h3 style="margin:0 0 10px">${E(x.fn)}</h3><iframe src="${x.f}" title="${E(x.fn)}" style="width:100%;height:65vh;border:1px solid var(--line);border-radius:4px"></iframe><div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">닫기</button><a class="btn r" href="${x.f}" download="${E(x.fn)}">다운로드</a></div>`,"760px")}
case"pvf":{const x=r.lib[+d.i];const body=x.k==="이미지"?`<img src="${x.f}" alt="${E(x.n)}" style="max-width:100%;max-height:65vh;display:block;margin:0 auto;border-radius:4px">`:x.k==="PDF"?`<iframe src="${x.f}" title="${E(x.n)}" style="width:100%;height:65vh;border:1px solid var(--line);border-radius:4px"></iframe>`:`<p class="empty">이 형식은 미리보기를 지원하지 않아요. 다운로드해서 확인해 주세요.</p>`;
return openM(`<h3 style="margin:0 0 10px">${E(x.n)}</h3>${body}<div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">닫기</button><a class="btn r" href="${x.f}" download="${E(x.n)}">다운로드</a></div>`,"760px")}
case"libAdd":{const f=$("#lfile").files[0],u=$("#lurl").value.trim();if(f){const n=f.name,k=okImg(f)?"이미지":okPdf(f)?"PDF":"";if(!k)return toast("이미지는 jpg, png, PDF는 pdf 파일만 올릴 수 있어요. 그 밖의 자료는 링크로 공유해 주세요.");r.lib.unshift({k,n,f:URL.createObjectURL(f)})}else if(/^https?:\/\//.test(u))r.lib.unshift({k:"링크",n:u,u});else return toast("파일을 고르거나 https:// 링크를 입력해 주세요.");break}
case"vAdd":{const q=$("#vq").value.trim(),o=$("#vo").value.split("\n").map(s=>s.trim()).filter(Boolean);if(!q||o.length<2)return toast("질문과 선택지를 2개 이상 입력해 주세요.");r.vt.unshift({q,o:o.map(x=>({x,n:0})),my:-1});break}
case"vote":{const v=r.vt[+d.v],i=+d.o;if(v.my>=0)v.o[v.my].n--;v.my=v.my===i?-1:i;if(v.my>=0)v.o[i].n++;break}
case"av":r.av[d.k]=!r.av[d.k];break;
case"rm":{const it=r[d.k][+d.i],nm=it.t||it.q||it.n;return openM(`<h3 style="margin:0 0 6px">${RMN[d.k]} 삭제</h3><p class="m">"${E(nm)}" ${RMN[d.k]}을(를) 삭제할까요? 삭제하면 되돌릴 수 없어요.</p><div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">취소</button><button class="btn r" data-a="rmOk" data-k="${d.k}" data-i="${d.i}">삭제하기</button></div>`)}
case"ed":{const k=d.k,i=d.i,it=r[k][+i];let f="";
if(k==="nt")f=`<label for="xt">제목</label><input id="xt" value="${E(it.t)}"><label for="xb">내용</label><textarea id="xb" rows="3">${E(it.b)}</textarea><label for="xu">링크</label><input id="xu" value="${E(it.u)}" placeholder="https://…">`;
else if(k==="vt")f=`<label for="xt">투표 질문</label><input id="xt" value="${E(it.q)}"><label for="xb">선택지 (줄바꿈으로 구분, 2개 이상)</label><textarea id="xb" rows="4">${E(it.o.map(o=>o.x).join("\n"))}</textarea><p class="m" style="margin:6px 0 0">그대로 둔 선택지는 표 수가 유지되고, 새 선택지는 0표부터 시작해요.</p>`;
else f=`<label for="xd">날짜</label><input id="xd" type="date" value="${it.d}"><label for="xt">일정 제목</label><input id="xt" value="${E(it.t)}"><label style="margin-top:10px"><input type="checkbox" id="xc" ${it.todo?"checked":""}> 해야할 일 태그 붙이기</label>`;
return openM(`<h3 style="margin:0 0 6px">${RMN[k]} 수정</h3>${f}<div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">취소</button><button class="btn r" data-a="edOk" data-k="${k}" data-i="${i}">저장하기</button></div>`)}
case"edOk":{const k=d.k,it=r[k][+d.i],t=$("#xt").value.trim();
if(k==="nt"){if(!t)return toast("공지 제목을 입력해 주세요.");Object.assign(it,{t,b:$("#xb").value.trim(),u:$("#xu").value.trim()})}
else if(k==="vt"){const o=[...new Set($("#xb").value.split("\n").map(s=>s.trim()).filter(Boolean))];if(!t||o.length<2)return toast("질문과 선택지를 2개 이상 입력해 주세요.");
const mx=it.my>=0?it.o[it.my].x:null;it.o=o.map(x=>({x,n:(it.o.find(p=>p.x===x)||{n:0}).n}));it.q=t;it.my=mx===null?-1:it.o.findIndex(p=>p.x===mx)}
else{const dt=$("#xd").value;if(!dt||!t)return toast("날짜와 일정 제목을 입력해 주세요.");const td=$("#xc").checked?1:0;Object.assign(it,{d:dt,t,todo:td,done:td?it.done:0})}
closeM();toast(RMN[k]+"을(를) 수정했어요.");break}
case"rmOk":r[d.k].splice(+d.i,1);closeM();toast(RMN[d.k]+"을(를) 삭제했어요.");break;
case"evAdd":{const dt=$("#ed").value,t=$("#et").value.trim();if(!dt||!t)return toast("날짜와 일정 제목을 입력해 주세요.");r.ev.push({d:dt,t,todo:$("#etd").checked?1:0,done:0});S.sel=dt;break}
case"todo":{const e=r.ev[+d.i];e.done=e.done?0:1;break}
case"affSave":S.prof.aff=$("#aff").value.trim();toast("소속을 저장했어요.");break;
case"awAdd":{const v=$("#awi").value.trim();if(!v)return toast("수상내역을 입력해 주세요.");S.prof.aw.push(v);break}
case"awDel":S.prof.aw.splice(+d.i,1);break;
case"pfAdd":{const t=$("#pft").value.trim(),u=$("#pfu").value.trim();if(!t||!/^https?:\/\//.test(u))return toast("제목과 https:// 링크를 입력해 주세요.");S.prof.pf.push({t,u});break}
case"pfDel":S.prof.pf.splice(+d.i,1);break;
case"result":{const x=myApp(+d.id);x.st="c";x.res=x.tid%2?"불":"합";break}
case"skip":return openM(`<h3 style="margin:0 0 6px">불참여</h3><p class="m">"${E(TM.find(t=>t.id===+d.id).name)}" 팀에 합격했지만 참여하지 않을까요? 팀장에게 불참여가 전달되고 되돌릴 수 없어요.</p><div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">취소</button><button class="btn r" data-a="skipOk" data-id="${d.id}">불참여하기</button></div>`);
case"skipOk":S.apps=S.apps.filter(a=>a.tid!==+d.id);closeM();toast("불참여 처리했어요.");break;
case"confirm":{const x=myApp(+d.id);if(x.res==="합"){x.st="a";TM.find(t=>t.id===x.tid).mem.push(S.user.name+"("+x.role+")");toast("팀에 참여했어요. 팀채팅에서 만나요.")}else{S.apps.splice(S.apps.indexOf(x),1);toast("결과를 확인했어요.")}break}
case"pv":{const x=S.recv[+d.i],L=(a,f)=>a.length?a.map(f).join(""):`<p class="empty" style="padding:4px 0">없음</p>`;return openM(`<h3 style="margin:0 0 2px">${E(x.n)} <span class="rl">${E(x.role)} 지원</span></h3><p class="m" style="margin:0">${E(x.aff)}${x.rt?` · <span class="stars">★ ${x.rt.toFixed(1)}</span>`:" · 받은 후기 없음"}</p>
<div class="sh">자기소개</div><p style="margin:2px 0">${E(x.intro)}</p>
<div class="sh">경력</div>${L(x.car,c=>`<div class="it" style="padding:6px 0">${E(c)}</div>`)}
<div class="sh">수상내역</div>${L(x.aw,c=>`<div class="it" style="padding:6px 0">${E(c)}</div>`)}
<div class="sh">포폴 / 작업물</div>${L(x.pf,p=>`<div class="it" style="padding:6px 0"><a class="red" href="${E(p.u)}" target="_blank" rel="noopener">${E(p.t)}</a></div>`)}
<div class="row" style="justify-content:flex-end;margin-top:16px"><button class="btn o" data-a="close">닫기</button><button class="btn o" data-a="recv" data-i="${d.i}" data-v="0">불합격</button><button class="btn r" data-a="recv" data-i="${d.i}" data-v="1">합격</button></div>`)}
case"recv":{closeM();const x=S.recv.splice(+d.i,1)[0];if(+d.v){TM.find(t=>t.id===x.tid).mem.push(x.n+"("+x.role+")");toast(x.n+"님을 합격 처리했어요.")}else toast(x.n+"님을 불합격 처리했어요.");break}
case"rate":S.rate=+d.v;document.querySelectorAll(".rate button").forEach(x=>x.classList.toggle("on",+x.dataset.v<=S.rate));return;
case"rvW":return rvM(+d.p,d.n);
case"rvOk":{const t=$("#rvt").value.trim();if(!t)return toast("후기 내용을 입력해 주세요.");S.gv.push({p:+d.p,n:d.n,s:S.rate,t});closeM();toast(d.n+"님에게 후기를 남겼어요.");break}
case"rvDel":return openM(`<h3 style="margin:0 0 6px">후기 삭제</h3><p class="m">${E(d.n)}님에게 남긴 후기를 삭제할까요? 삭제하면 되돌릴 수 없어요.</p><div class="row" style="justify-content:flex-end"><button class="btn o" data-a="close">취소</button><button class="btn r" data-a="rvDelOk" data-p="${d.p}" data-n="${E(d.n)}">삭제하기</button></div>`);
case"rvDelOk":S.gv=S.gv.filter(x=>!(x.p===+d.p&&x.n===d.n));closeM();toast("후기를 삭제했어요.");break;
}render()}

